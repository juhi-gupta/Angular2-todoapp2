# Angular 2 Todo App

This repository contains the source code for the [SitePoint](https://www.sitepoint.com) article ["Angular 2 Todo App - Part 1"](https://www.sitepoint.com) by [Todd Motto](https://twitter.com/toddmotto) and [Jurgen Van de Moere](https://twitter.com/jvandemo).

![angular2-todo-app](https://cloud.githubusercontent.com/assets/1859381/16371153/f36fae94-3c44-11e6-96db-878901598c3a.gif)

Here is a [live demo](https://jvandemo.github.io/angular2-todo-app/) of the application.

## Attention - repository has moved!
The code for the article series has been moved to https://github.com/sitepoint-editors/angular-todo-app.
